repo: trinhthu88/wealth-app
branch: main
path: artifacts/wealthapp/src

## Last sync

date: 2026-08-28
- Built the advised investment-client mobile app (14 screens) as `tala Advised Client App.dc.html`, Sunrise 1A visual direction.
- Nav structure lifted from `components/client/AppShell.tsx` (5-slot bottom tabs + More drawer).
- All figures taken from Elena Novak (Track A) in `scripts/src/seed-demo-data.ts`.
- Sol copy written against the boundary rules in `SOL_PERSONA.md` — explains, never directs.

## Screen map

| Screen | Built from |
|---|---|
| Home | pages/client/ClientDashboard.tsx |
| Portfolio | pages/client/ClientPortfolio.tsx |
| Plan detail | pages/client/AdvisedPlanDetail.tsx |
| Fund detail | pages/client/HoldingDetail.tsx |
| Pathway | pages/client/ClientPlan.tsx |
| What if | pages/client/ClientScenarios.tsx |
| Goals | pages/client/ClientGoals.tsx |
| Net worth | pages/client/ClientNetWorth.tsx |
| Budget | pages/client/ClientBudget.tsx |
| Transactions | pages/client/transactions.tsx |
| Messages | pages/client/messages.tsx |
| Documents | pages/client/documents.tsx |
| Packages | pages/client/packages.tsx |
| Package detail | pages/client/package-detail.tsx |
| Nav / shell | components/client/AppShell.tsx |
