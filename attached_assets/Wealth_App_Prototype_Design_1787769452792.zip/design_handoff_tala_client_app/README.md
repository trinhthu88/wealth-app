# Handoff: tala — advised client app, "Sunrise" direction (1A)

## Overview

Mobile app for **tala**, a wealth platform for expats in Vietnam and SEA. This handoff covers the **advised investment client** experience: a client whose money is managed by a tala adviser, who wants to see where they stand, what happens next, and what their adviser is doing.

Seven screens: Home, Portfolio, Pathway, Goals, Budget, Financial health, Scenarios.

The defining element is **Sol**, an abstract sun mascot who acts as a full companion: he greets the client by name on Home, comments on goals and budget, sits at the top of the health-score gauge, and appears in the tab bar as an entry point to conversation. Tone is a warm coach — plain language, encouraging, never salesy.

## About the design files

`tala-sunrise-1a-reference.html` in this folder is a **design reference created in HTML** — a prototype showing intended look and behaviour, not production code to lift. Open it in a browser to see all seven screens side by side in phone frames.

The task is to **recreate these designs in the target codebase's existing environment** (React Native, Expo, React web, whatever the app is built on) using its established component patterns, navigation, and state libraries. If no environment exists yet, choose the framework that fits the product and implement there. Do not ship the HTML.

Note: the frames, the desk background, the badge/heading chrome and the `data-screen-label` attributes are presentation scaffolding for review. Only the content inside each 390×844 frame is the design.

## Fidelity

**High fidelity.** Colours, type, spacing, radii and copy are final-intent. Recreate pixel-close, substituting the codebase's own primitives where they exist (buttons, list rows, sheets) rather than inventing new ones. All numbers are illustrative sample data for one persona.

## Sample persona (placeholder data)

Marcus Reid, expat in Ho Chi Minh City, age 45. Net worth $842,300, of which $612,480 is managed by tala. Adviser: Linh Pham ("LP"). Health score 78/100. Goals: retire in Da Nang 2043 ($1.8M), international school fund 2031 ($240,000), property deposit 2028 ($120,000). Replace with real data from the API.

---

## Design tokens

### Colour

| Token | Hex | Use |
|---|---|---|
| `paper` | `#FDF6EC` | Screen background (light screens) |
| `surface` | `#FFFFFF` | Cards |
| `forest` | `#14342A` | Primary dark; text on paper, dark cards, dark screen bg |
| `forest-700` | `#1D4A3A` | Card surface on dark screens |
| `forest-900` | `#0E2620` | Tab bar on dark screens |
| `green` | `#1D9E75` | Primary accent, positive values, active nav |
| `green-300` | `#7FC9A6` | Chart tertiary |
| `green-tint` | `#E7F5EE` | Positive pill background |
| `mint` | `#8FBFA9` | Secondary text on forest |
| `sun` | `#FFB627` | Sol's body, milestone accents, FAB |
| `sun-deep` | `#F5A623` | Sol's rays, badge |
| `sun-tint` | `#FFF0DA` | Warm callout card |
| `sun-ink` | `#3A2405` | Sol's face; text on sun |
| `amber-ink` | `#5A3A0A` / `#B07A22` | Text on `sun-tint` |
| `clay` | `#E8663D` | Negative / behind |
| `clay-tint` | `#FDEDE7` | Negative callout bg |
| `clay-ink` | `#A3452A` / `#7A2E17` | Text on `clay-tint` |
| `ink-60` | `#4A5C54` | Body text |
| `ink-40` | `#7A8B82` | Secondary label |
| `ink-30` | `#8C9A93` | Tertiary / meta |
| `ink-20` | `#A6B3AC` | Inactive nav |
| `hairline` | `#F2E9DB` | List separators inside cards |
| `hairline-2` | `#EDE3D4` | Tab bar top border |
| `track` | `#EFE5D6` | Progress / gauge track (light) |
| `track-dark` | `#2F5A48` | Progress track on forest |
| `sand` | `#E4D7C3` | Chart "other" segment |

Max two background colours per flow: `paper` for most screens, `forest` for Pathway (and any screen meant to read as "the long view").

### Typography

Two families, loaded from Google Fonts:

- **Bricolage Grotesque** — display. Weights 500/600. Used for screen titles, all large numbers, card headings. `letter-spacing: -0.02em` at 30px+, `-0.01em` at 19–26px.
- **Figtree** — UI. Weights 400/500/600. All body copy, labels, list rows, nav.

Scale as used:

| Role | Family | Size | Weight |
|---|---|---|---|
| Screen title | Bricolage | 30px | 600 |
| Hero number (net worth) | Bricolage | 44px | 600 |
| Hero number (score) | Bricolage | 52px | 600 |
| Card number | Bricolage | 24–26px | 600 |
| Sol greeting | Bricolage | 23px | 500 |
| Card heading | Bricolage | 17–20px | 600 |
| Section subtitle | Figtree | 14px | 400 |
| List row primary | Figtree | 15px | 600 |
| List row secondary | Figtree | 13px | 400 |
| Body / Sol speech | Figtree | 14px | 400, line-height 1.5 |
| Eyebrow label | Figtree | 13px | 600, `letter-spacing .06em`, uppercase |
| Tab label | Figtree | 11.5px | 600 |

All monetary figures use `font-variant-numeric: tabular-nums`. Long copy uses `text-wrap: pretty`.

### Spacing, radius, shadow

- Screen horizontal padding: **22px** (26px on the Pathway screen).
- Gap between stacked cards: **14px**. Gap inside a card between blocks: **12–16px**.
- Card padding: **20–24px**; small callout padding: **16px 18px**.
- Radii: card **26–28px**, hero card **32px**, callout **20–24px**, inner tint block **16px**, pill/dot **999px**, progress bar **999px**.
- Card shadow: `0 2px 14px rgba(20,52,42,.06)`. Cards on `forest` have no shadow.
- Progress bar heights: 6px (light), 7px (on forest), 14px (budget composition).
- Tab bar: 88px tall, `#FFFFFF` with 1px `hairline-2` top border; centre FAB is a 34px `sun` circle raised 6px above the row.

### Device frame (reference only)

390×844 content, 46px outer radius, 52px status bar. Use real safe-area insets in implementation.

---

## Sol — the mascot

Sol is drawn as SVG, never as a raster asset, so he can scale and animate.

**Construction** (64px canvas, full form):
- 8 rays: 3px stroke, `sun-deep` `#F5A623`, round caps, at 0/45/90/…°, from r=28 to r=31 of a 32-centre.
- Body: circle r=21, fill `sun` `#FFB627`, 1.5px stroke `#E8963D`.
- Eyes: two r=2.6 circles, fill `sun-ink`, at (25,29) and (39,29).
- Mouth: `M25 37.5 Q32 43 39 37.5`, 2.4px stroke `sun-ink`, round cap.

**Sizes and where he appears**
| Size | Placement |
|---|---|
| 64px, rays | Home greeting |
| 34px, no rays | Tab bar FAB is a plain sun circle; Sol's face appears in Pathway and Budget callouts at 32–34px |
| 34px, no rays | Inline callout avatar |
| 34px, no rays | Perched at the top centre of the health-score gauge arc |
| 24px text label | "Sol" as a green word-label prefix in Goals card notes |

**Motion** (all CSS, all subtle, all `prefers-reduced-motion` aware — disable everything below when reduced motion is set)
- `solSpin` — rays rotate 360° over **46s** linear, infinite. Body and face do not rotate.
- `solBlink` — eye group `scaleY(1 → 0.1 → 1)` in the last 8% of a **6s** loop; transform-origin at eye line.
- `solBreathe` — whole 64px Sol `scale(1 → 1.045 → 1)` over **5s** ease-in-out.
- `solGlow` — the large sun halo on Pathway fades `opacity .35 → .7 → .35` over **7s**.
- `sparkle` — celebration `✦` marks scale/fade `0 → 1 → 0` over **2.4s**, staggered 0.8s.
- `riseUp` — celebration banner enters `translateY(6px)` + fade over **0.5s** ease.
- `drawIn` — line/arc charts animate `stroke-dashoffset 400 → 0` over **1.6–1.8s** ease-out, once on mount.

**Voice rules for Sol's copy**
- Second person, present tense, one idea per line, max ~14 words.
- Always pairs an observation with a next step, and the next step is optional ("Want me to model it?").
- Never uses exclamation marks, emoji, or product jargon.
- Never delivers bad news without a number that fixes it ("$180 more a month closes the gap").

---

## Screens

### 1. Home
**Purpose:** orient in five seconds — where I stand, what just happened, what's next.

Vertical stack, 22px gutters:
1. **Sol greeting** — 64px Sol left, text right. Eyebrow "Sol" (13px 600, `#C98A2E`, uppercase, `.06em`). Greeting in Bricolage 23px/500 `forest`: "Morning, Marcus. You're a third of the way to Da Nang." Greeting varies by time of day and by the most notable change since last open.
2. **Celebration banner** (conditional) — `forest` card, radius 22px, 16px 18px padding. 34px `sun` circle with `✓`, then title 15px/600 `paper` and subtitle 13px `mint`. Two animated `✦` sparkles positioned top-right and lower-right. Enters with `riseUp`. Shown once per newly-met milestone, dismissed on scroll away or tap.
3. **Net worth card** — white, radius 26px. Header row: "Net worth" (14px/600 `ink-40`) and a `green-tint` pill "+8.4% YTD" (13px/600 `green`, radius 999px, 4px 9px). Value Bricolage 44px/600. Sub-line "$612,480 invested with tala" 14px `ink-40`. Area chart 300×70, `green` 2.5px line with a vertical `green` 28%→0% gradient fill, 4px end dot, `drawIn` on mount.
4. **Two-up row**, 12px gap: left `forest` card — "Health score" 13px/600 `mint`, "78/100" Bricolage 32px (the "/100" 16px `mint`), "Strong · up 6 pts". Right `sun-tint` card — "Next milestone" `#B07A22`, "Property deposit" Bricolage 19px `amber-ink`, "2028 · 45% there".
5. **Adviser card** — white radius 26px. Heading "This month with Linh" Bricolage 17px + "View" 13px/600 `green` right-aligned. Row: 38px `#DCEAE3` initials circle, then 14px `ink-60` line about the next appointment.

**Tab bar:** Home (active `green`), Plan, **Sol** (centre FAB), Goals, More.

### 2. Portfolio
Title "Portfolio" + "Balanced growth · reviewed 12 Aug".

- **Allocation card** — white radius 28px, 132px donut left (18px stroke, rotated −90°, segments `green` 42%, `green-300` 18%, `forest` 22%, `sun` 10%, `sand` 8%), legend right with total in Bricolage 26px above five 13.5px rows each led by a 10px rounded square swatch.
- **Segmented pills** — Holdings (active: `forest` fill, `paper` text), Performance, Fees (white, `ink-40`). 13px/600, 8px 14px, radius 999px, 10px gap.
- **Holdings list** — white card radius 26px, rows separated by 1px `hairline`, 15px vertical padding. Left: name 15px/600 + provider/ticker 13px `ink-30`. Right, aligned right: value 15px/600 tabular, then change 13px/600 in `green` or `clay`; `—` in `ink-30` for cash.

### 3. Pathway
The one dark screen. Background `forest`, tab bar `forest-900`.

- A 200px `sun` circle at 14% opacity bleeds off the top-right corner, animating `solGlow`.
- Title "Your pathway" `paper`, subtitle "Five suns between here and Da Nang" `mint`.
- **Vertical timeline**, 34px left inset. A 2px rail runs the full height with a gradient: `sun` down to 22%, then `track-dark` from 40% — the rail is lit only as far as progress.
- Node states: **done** — 24px `sun` circle with a `sun-ink` `✓`; **current** — 24px `paper` circle with a 3px `sun` ring; **future** — 24px transparent circle with a 2px `#4E7A66` ring, whole entry at 82% opacity.
- Each entry: year eyebrow 12.5px/600 `.06em` (`sun` for done/current, `#6E9C85` for future), title Bricolage 20px, detail 13.5px. The current entry also has a 7px progress bar (`track-dark` track, `sun` fill).
- **Sol footer callout** — `forest-700` card radius 22px, 34px Sol, 14px `#DCEAE3` copy offering to model a change.

### 4. Goals
Title "Goals" with a 36px `forest` circle `+` button; subtitle "Three live · $2.16M in play".

Three white cards, radius 28px, 14px apart. Each: 76px progress ring left (33r, 9px stroke, `track` background, coloured arc, round cap, rotated −90°) and text right — title Bricolage 20px, meta 13.5px `ink-40`, then "$612,000 **of** $1.8M" at 15px with the target in 400 `ink-30`.

Ring colour signals status: on track `green`, near-term `sun`, behind `clay`.

Two cards carry a note block, radius 16px, 12px 14px, 13.5px:
- On track — `#F5FAF7` bg, `#3F6B58` text, prefixed by a bold `green` "Sol" label.
- Behind — `clay-tint` bg, `clay-ink` text, with the corrective number.

### 5. Budget
Title "August", subtitle "11 days left in the month".

- **Summary card** — white radius 28px. Three columns In / Out / Invested; labels 13px/600 (`ink-40`, `ink-40`, `green`), values Bricolage 24px (Invested in `green`). Below, a 14px-tall composition bar: five flex segments (`forest` 31, `green` 18, `green-300` 12, `sun` 22, `sand` 17), 2px gaps, radius 999px on the container. Footer line names the surplus, amount bolded in `forest`.
- **Sol suggestion** — `sun-tint` card radius 24px, 32px Sol, 14px `amber-ink` copy proposing a sweep into a goal.
- **Category list** — white card radius 26px. Rows: a 10×34px rounded bar in the category's chart colour, name 15px/600 + note 13px `ink-30`, amount 15px/600 tabular right. `hairline` separators, no separator on the last row.

### 6. Financial health
Title "Financial health".

- **Gauge card** — white radius 32px, centred. A 200×130 SVG半 arc: `track` 16px background arc, `green` 16px value arc with `drawIn`, both round-capped. A 17px Sol (body + face, no rays) sits at the arc's apex, blinking. The score "78" in Bricolage 52px overlaps the gauge with `margin-top:-38px`. Below: status line 15px/600 `green` and a 14px `ink-40` peer comparison.
- **Factor list** — white radius 26px, five rows. Each row: label 15px/600 left, verdict 14px/600 right (`green` excellent/good, `#C98A2E` watch, `clay` gap), then a 6px `track` bar with a coloured fill.
- **Closing callout** — `forest` card radius 22px, 14px `#DCEAE3`, the improved score highlighted in `sun`, and a concrete adviser action.

### 7. Scenarios
Title "What if", subtitle "Move a lever, watch Da Nang move".

- **Projection card** — `forest`, radius 30px. Header "Projected at 62" (`mint`) and a `sun` pill "87% success" with `forest` text. Value Bricolage 40px `paper`, sub-line in `mint`. 300×110 chart: a confidence band filled with a `sun` 38%→5% vertical gradient, a 2.5px `sun` median line (`drawIn`), and a dashed `#4E7A66` target line labelled "target $1.8M" at 10px `mint`.
- **Levers card** — white radius 26px, three sliders 20px apart. Each: label 14.5px/600 `forest` left, current value 14.5px/600 `green` right, then a 6px `track` rail with a `green` fill and a 22px white thumb (3px `green` border, `0 2px 8px rgba(20,52,42,.25)`). Levers: retirement age, monthly contribution, assumed return.
- **Preset comparison row** — three equal tiles, 10px gap, radius 20px, centred: `sun-tint` "Retire at 58 / 64%", `green-tint` "Add $500/mo / 94%", `clay-tint` "Career break / 71%". Label 12.5px/600, figure Bricolage 19px.

---

## Interactions & behaviour

- **Tab navigation** — five tabs; the centre Sol FAB opens a conversational sheet rather than a tab (not designed in this pass; treat as a modal bottom sheet).
- **Sliders (Scenarios)** — dragging recomputes the projection value, success percentage and chart. Debounce recomputation ~120ms; animate the value with a short count-up and the chart line with a 300ms ease transition, not a fresh `drawIn`.
- **Segmented control (Portfolio)** — swaps the list beneath; no layout shift on the allocation card.
- **Goal / holding rows** — tappable into a detail view (not designed).
- **Celebration banner** — appears when a milestone crosses complete; `riseUp` entrance, sparkles loop while visible, dismisses on tap or on next app open.
- **Chart mount animations** — run once per screen entry, not on every re-render or state change.
- **Sol** — always animating idly (spin, blink, breathe) at low amplitude. He never blocks input and never interrupts with a modal.
- **Press states** — cards darken by ~3% on press; the `+` and FAB scale to 0.96 for 100ms.
- **Reduced motion** — disable spin, breathe, glow, sparkle, and chart draw-in; keep instant final states.

## State

Per screen, the minimum:

- `client` — name, greeting slot, adviser (name, initials, next appointment).
- `netWorth` — total, managed, ytdPercent, series[] for the sparkline.
- `milestones[]` — { year, title, detail, status: done | current | future, progress }.
- `goals[]` — { title, meta, current, target, status, note }.
- `budget` — month, daysLeft, in, out, invested, surplus, categories[] { name, note, amount, colour, varianceVsPlan }.
- `health` — score, delta, percentile, factors[] { name, verdict, value, tone }.
- `scenario` — retireAge, monthlyContribution, assumedReturn (all client-editable) → derived median, successPercent, series[]; plus presets[] { label, successPercent, tone }.
- `celebration` — { milestoneId, seen } persisted so the banner shows once.
- `portfolio` — total, terPercent, allocation[] { label, weight, colour }, holdings[] { name, ticker, provider, value, changePercent }.

Scenario levers are the only client-writable state in this flow; everything else is read-only from the adviser platform.

## Assets

None external. Sol and every chart are inline SVG defined in the reference file. Fonts are Google Fonts (Bricolage Grotesque, Figtree) — self-host in production.

No design system was attached with a style guide, so the palette and type above are original to this direction and are the source of truth. (The project's `uploads/` folder contains HSP Consulting logos and an IFA brochure; none of that branding is used here.)

## Files

- `tala-sunrise-1a-reference.html` — all seven screens, standalone, opens in any browser.
- Source of record in the design project: `tala Prototype.dc.html` (contains this direction as **1A** plus a second, colder direction **1B** for comparison).
